#include "stdafx.h"
#include "Scene2.h"
#include "ArrowButton.h"
#include "Inventory.h"

Scene2::Scene2()
	: Scene(SceneIds::Scene2)
{
}

void Scene2::Init()
{
	Inventory::Instance().Init();
	ResourceLoad();
	TEXTURE_MGR.Load(texIds);

	sf::Vector2f windowSize = FRAMEWORK.GetWindowSizeF();
	sf::Vector2f size(25.f, 30.f);

	sf::Vector2f center = windowSize * 0.5f;
	sf::Vector2f tvSize(270.f, 250.f);

	sf::FloatRect tvClickableArea(center.x - tvSize.x * 0.5f, center.y - tvSize.y * 0.5f, tvSize.x, tvSize.y);

	sf::Texture& tvTex = TEXTURE_MGR.Get("graphics/tv_ui.png");

	tvUi.Init(tvTex, center);
	tvUi.SetClickableArea(tvClickableArea);

	leftArrow = new ArrowButton(ArrowDirection::Left, { 150, windowSize.y / 2 - 20 }, size);
	rightArrow = new ArrowButton(ArrowDirection::Right, { windowSize.x - 370, windowSize.y / 2 - 20 }, size);

	background2.setPosition(0.f, 0.f);
	background2.setTexture(TEXTURE_MGR.Get(texId2), true);

	tvRect.setSize(tvSize);
	tvRect.setPosition(tvClickableArea.left, tvClickableArea.top);
	tvRect.setFillColor(sf::Color(255, 0, 0, 100));
	tvRect.setOutlineThickness(3.f);
	tvRect.setOutlineColor(sf::Color::Green);

	SetUpViews();

	leftArrow->SetCallBack([this]() {
		if (tvUi.IsVisible())
			tvUi.Hide();
		});

	rightArrow->SetCallBack([this]() {
		if (tvUi.IsVisible())
			tvUi.Hide();
		SCENE_MGR.ChangeScene(SceneIds::Scene1);
		});

	Scene::Init();
}

void Scene2::Enter()
{
	Scene::Enter();
	ResourceLoad();
	TEXTURE_MGR.Load(texIds);

	background2.setTexture(TEXTURE_MGR.Get(texId2), true);
	if (tvUi.IsOpened())
	{
		tvUi.ChangeTexture(TEXTURE_MGR.Get("graphics/tv_ui.png"));
	}
	else
	{
		tvUi.ChangeTexture(TEXTURE_MGR.Get("graphics/tv_ui.png"));
	}
}

void Scene2::Exit()
{
	Scene::Exit();
}

void Scene2::Update(float dt)
{
	Scene::Update(dt);
	InputMgr::Update(dt);

	if (InputMgr::GetMouseButtonDown(sf::Mouse::Left))
	{
		sf::Vector2f mousePosF = FRAMEWORK.GetWindow().mapPixelToCoords(InputMgr::GetMousePosition());

		if (tvUi.CheckClick(mousePosF))
		{
			tvUi.Show();
		}

		Inventory::Instance().HandleClick(mousePosF);
	}

	if (leftArrow) leftArrow->Update(dt);
	if (rightArrow) rightArrow->Update(dt);
}

void Scene2::ResourceLoad()
{
	texIds.push_back(texId2);
	texIds.push_back("graphics/tv_ui.png");
}

void Scene2::SetUpViews()
{
	sf::Vector2f windowSize = FRAMEWORK.GetWindowSizeF();

	background2.setTexture(TEXTURE_MGR.Get(texId2), true);
	uiView.setSize(windowSize);
	uiView.setCenter(windowSize * 0.5f);
}

void Scene2::HandleEvent(const sf::Event& event)
{
	InputMgr::UpdateEvent(event);
	FRAMEWORK.GetWindow().setView(uiView);

	if (leftArrow)
		leftArrow->HandleEvent(event, FRAMEWORK.GetWindow());

	if (rightArrow)
		rightArrow->HandleEvent(event, FRAMEWORK.GetWindow());
}

void Scene2::Draw(sf::RenderWindow& window)
{
	window.setView(uiView);

	window.draw(background2);

	window.draw(tvRect);

	if (tvUi.IsVisible())  
		tvUi.Draw(window);

	if (leftArrow) leftArrow->Draw(window);
	if (rightArrow) rightArrow->Draw(window);

	Inventory::Instance().Draw(window);
}
