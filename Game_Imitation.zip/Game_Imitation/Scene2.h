#pragma once
#include "Scene.h"
#include "ZoomUI.h"
#include "NumPad.h"

class ArrowButton;
class Scene2 : public Scene
{
protected:

	ArrowButton* leftArrow = nullptr;
	ArrowButton* rightArrow = nullptr;

	sf::Sprite background2;
	std::string texId2 = "graphics/scene2_bg.png";

	ZoomUI tvUi;

	sf::RectangleShape tvRect;

	bool isBatteryUsed = false;

public:
	Scene2();

	void Init() override;
	void Enter() override;
	void Exit() override;
	void Update(float dt) override;
	void ResourceLoad();
	void SetUpViews();
	void Draw(sf::RenderWindow& window) override;
	virtual void HandleEvent(const sf::Event& event) override;

};

